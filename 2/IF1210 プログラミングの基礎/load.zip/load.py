import argparse
import os.path

#argparse hanya untuk memasukkan nama folder yang ingin dicari (belum dilakukan proses apa apa)
parser = argparse.ArgumentParser()
parser.add_argument("foldername", help="Masukkan nama folder yang ingin dicari/ditambahkan",nargs="?")
args = parser.parse_args()

def findlength(file):
    count = 0
    for  line in file :
        count =+ 1
    
    return count

#buat fungsi split untuk misahin array untuk tiap csv
def splitarray(baris, jumlahkolom) :
    variabelsementara = ""

    arr_hasilsplit = [None for i in range (jumlahkolom)]
 
    j=0
    for i in range (len(baris)) :
        if ((baris[i]) != ";") and (i != len(baris)-1) :
            variabelsementara += baris[i]
        else :
            arr_hasilsplit[j] = variabelsementara
            j+=1
            variabelsementara=""

    return arr_hasilsplit

#cari apakah nama folder yang diinput ada ataupun tidak di komputer menggunakan if-else

#kondisi 1 : nama folder yang diinput ditemukan 
if os.path.isdir(args.foldername) :
    #untuk pindahin data user dari format csv ke format array
    folder = open(args.foldername+"/user.csv", 'r')
    arr_user = [None for i in range (103)]  #103 = 100 jin (jumlah maks jin) + headline + rorojonggrang +bandung bondowoso
    
    j=0
    for i in folder.readlines() :
        arr_user[j] = splitarray(i, 3) #baris = i, kolom = 3(jumlah kolom di file user.csv)
        j+=1

    folder.close()
    print(arr_user)


    #untuk pindahin data bahanbangunan dari format csv ke format array
    folder = open(args.foldername+"/bahan_bangunan.csv", 'r')
    arr_bahanbangunan = [None for i in range (4)] #4 = headline + pasir + batu + air

    j=0
    for i in folder.readlines() :
        arr_bahanbangunan[j] = splitarray(i, 3) #kolom = 3 = (nama, deskripsi, jumlah)
        j+=1
    
    folder.close()

    #untuk pindahin data candi dari format csv ke format array
    folder = open(args.foldername+"/candi.csv", 'r')
    arr_candi = [None for i in range (101)] #101 = headline + 100 candi (jumlah maks candi)

    j=0
    for i in folder.readlines() :
        arr_candi[j] = splitarray(i, 5) #kolom = 5 = id, pembuat, pasir, batu, air
        j+=1
        
    folder.close()



#kondisi 2 : nama folder yang diinput tidak ditemukan
elif not os.path.isdir(args.foldername) :
    print(f"Folder {(args.foldername)} tidak ditemukan.")

# kondisi 3 : tidak memasukkan nama file
#blm tau caranya gimana
elif (args.foldername) == None :
    parser.error("Tidak ada nama folder yang diberikan!")
