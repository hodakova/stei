from load import arr_candi
count = 0

for i in range (1,1000) :
    if ((arr_candi[i])[0] != None) :
        count = count + 1
    else : count = count

if (count >= 100) :
    print("Kukuruyuk... Kukuruyuk...")
    print("Jumlah Candi : ",100)
    print("Yah, Bandung Bondowoso memenangkan permainan!")
    print("Hayoloh harus nikah sama Mas Bondo :D")
    exit()
else :
    print("Kukuruyuk... Kukuruyuk...")
    print("Jumlah Candi : ",count)
    print("Selamat, Roro Jonggrang memenangkan permainan!")
    print("Hayoloh, Bandung Bondowoso marah")
    print("Roro Jonggrang dikutuk menjadi candi")
    exit()