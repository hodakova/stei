def logout():
    if dt.username == "": 
        print("Logout gagal! Anda belum login, silahkan login terlebih dahulu sebelum melakukan logout") # Jika pengguna belum melakukan login
    else: 
        print(f"Berhasil keluar dari, {dt.username}!") # Jika pengguna telah melakukan login, dan berhasil logout
        change_state(0)
        dt.username = ""