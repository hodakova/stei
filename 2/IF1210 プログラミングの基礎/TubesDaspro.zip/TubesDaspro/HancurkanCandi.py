from load import arr_candi

id_candi = int(input("Masukkan ID Candi : "))
persetujuan = input(f"Apakah anda yakin ingin menghancurkan candi ID : {id_candi} (Y/N)?")
found = False

if (persetujuan == 'N') :
    help()
else :
    for i in range (1,1000) :
        if (i == id_candi and (arr_candi[i])[0] != 0) :
            for j in range (5) :
                (arr_candi[i])[j] = 0
            found = True

if (found == False) :
    print("Tidak ada candi dengan ID tersebut")
else : print("Candi telah berhasil dihancurkan")