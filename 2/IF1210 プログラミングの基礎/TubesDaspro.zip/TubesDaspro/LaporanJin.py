from load import arr_user, arr_candi, arr_bahanbangunan

jin_pembangun = 0
jin_pengumpul = 0
count = 0
terajin = 0
termalas = 9999

for i in range (1,103) :
    if ((arr_user[i])[2] == "jin_pembangun") :
        jin_pembangun = jin_pembangun + 1
    elif ((arr_user[i])[2] == "jin_pengumpul") :
        jin_pengumpul = jin_pengumpul + 1
    else : 
        jin_pembangun = jin_pembangun
        jin_pengumpul = jin_pengumpul

total_jin = jin_pembangun + jin_pengumpul

for i in range (1,103) :
    for j in range (1,1000) :
        if (arr_user[i])[0] == (arr_candi[j])[1] :
            count = count + 1
    if terajin < count :
        terajin = count
        jin_terajin = (arr_user[i])[1]
    elif terajin == count :
        terajin = terajin
        if jin_terajin < (arr_user[i])[1] :
            jin_terajin = jin_terajin
        else : jin_terajin = (arr_user[i])[1]
    
    if termalas > count :
        termalas = count
        jin_termalas = (arr_user[i])[1]
    elif termalas == count :
        termalas = termalas
        if jin_termalas > (arr_user[i])[1] :
            jin_termalas = jin_termalas
        else : jin_termalas = (arr_user[i])[1]

jumlah_pasir = (arr_bahanbangunan[1])[2]
jumlah_air = (arr_bahanbangunan[2])[2]
jumlah_batu = (arr_bahanbangunan[3])[2]

print("Total Jin : ",total_jin)
print("Total Jin Pengumpul : ",jin_pengumpul)
print("Total Jin Pembangun : ",jin_pembangun)
print("Jin Terajin : ",jin_terajin)
print("Jin Termalas : ",jin_termalas)
print("Jumlah Pasir : ",jumlah_pasir)
print("Jumlah Air : ",jumlah_air)
print("Jumlah Batu : ",jumlah_batu)