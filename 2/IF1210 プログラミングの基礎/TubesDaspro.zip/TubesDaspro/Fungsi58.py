
# code
def ubahjin():    
    from load import arr_user
    idxjinpertama = 3
    usernamejin = str(input("Masukkan username jin : "))
    found = False
    for i in range(idxjinpertama,103):
        if usernamejin == (arr_user[i])[0]:
            found = True
            break
    if found:
        while True:
            if (arr_user[i])[2] == "jin_pengumpul":
                YorN = str(input("Jin ini bertipe \"Pengumpul\". Yakin ingin mengubah ke tipe \"Pembangun\" (Y/N)? "))
                if YorN == 'Y':
                    (arr_user[i])[2] = "jin_pembangun"
                    print("Jin berhasil diubah.")
                    break
            else:
                YorN = str(input("Jin ini bertipe \"Pembangun\". Yakin ingin mengubah ke tipe \"Pengumpul\" (Y/N)? "))
                if YorN == 'Y':
                    (arr_user[i])[2] = "jin_pengumpul"
                    print("Jin berhasil diubah.")
                    break
            if YorN == 'N':
                print("Jin tidak diubah.")
                break
    else: print("Tidak ada jin dengan username tersebut.")

def rawkumpul():
    from load import arr_bahanbangunan
    import random
    foundpasir = random.randint(0,5)
    foundbatu = random.randint(0,5)
    foundair = random.randint(0,5)
    arr_bahanbangunan[1][2] += foundpasir
    arr_bahanbangunan[2][2] += foundbatu
    arr_bahanbangunan[3][2] += foundair
    return [foundpasir,foundbatu,foundair]

def kumpul():
    found = rawkumpul()
    print(f"Jin menemukan {found[0]} pasir, {found[1]} batu, dan {found[2]} air.")

def batchkumpul():
    from LaporanJin import jin_pengumpul
    totpengumpul = jin_pengumpul
    if totpengumpul > 0:
        print(f"Mengerahkan {totpengumpul} jin untuk mengumpulkan bahan.")
        founds = [0,0,0]
        for i in range(totpengumpul):
            found = rawkumpul()
            for i in range(3): founds[i] += found[i]
        print(f"Jin menemukan total {founds[0]} pasir, {founds[1]} batu, dan {founds[2]} air.")
    else: print("Kumpul gagal. Anda tidak punya jin pengumpul. Silahkan summon terlebih dahulu.")

def bangun():
    from load import arr_bahanbangunan, arr_candi
    import random
    reqpasir = random.randint(1,5)
    reqbatu = random.randint(1,5)
    reqair = random.randint(1,5)
    if arr_bahanbangunan[1][2] >= reqpasir and arr_bahanbangunan[2][2] >= reqbatu and arr_bahanbangunan[3][2] >= reqair:
        arr_bahanbangunan[1][2] -= reqpasir
        arr_bahanbangunan[2][2] -= reqbatu
        arr_bahanbangunan[3][2] -= reqair
        for id in range(1000):
            if (arr_candi[id])[0] == None: break
        arr_candi[id] = [id,(arr_candi[id])[1],reqpasir,reqbatu,reqair]
        print("Candi berhasil dibangun.")
        from laporanCandi import total_candi
        totcandi = total_candi
        if totcandi < 100: print(f"Sisa candi yang perlu dibangun : {100-totcandi}")
        else: print("Sisa candi yang perlu dibangun : 0")
    else:
        print("Bahan bangunan tidak mencukupi.")
        print("Candi tidak bisa dibangun!")

def batchbangun():
    from LaporanJin import jin_pembangun
    from load import arr_candi, arr_user, arr_bahanbangunan
    import random
    totpembangun = jin_pembangun
    if totpembangun > 0:
        tempcandi = [arr_candi[i] for i in range(1000)]
        totbahan = [0,0,0]
        idxjin = 3
        for i in range(totpembangun):
            while (arr_user[idxjin])[2] != "jin_pembangun": idxjin += 1
            reqpasir = random.randint(1,5)
            reqbatu = random.randint(1,5)
            reqair = random.randint(1,5)
            tempcandi[i] = [None,(arr_user[idxjin])[0],reqpasir,reqbatu,reqair]
            totbahan[0] += reqpasir
            totbahan[1] += reqbatu
            totbahan[2] += reqair
            idxjin += 1
        print(f"Mengerahkan {totpembangun} jin untuk membangun candi dengan total bahan {totbahan[0]} pasir, {totbahan[1]} batu, dan {totbahan[2]} air.")
        if arr_bahanbangunan[1][2] >= totbahan[0] and arr_bahanbangunan[2][2] >= totbahan[1] and arr_bahanbangunan[3][2] >= totbahan[2]:
            arr_bahanbangunan[1][2] -= totbahan[0]
            arr_bahanbangunan[2][2] -= totbahan[1]
            arr_bahanbangunan[3][2] -= totbahan[2]
            for i in range(totpembangun):
                for id in range(1000):
                    if (arr_candi[id])[0] == None: break
                arr_candi[id] = tempcandi[i]
                (arr_candi[id])[0] = id
            print(f"Jin berhasil membangun total {totpembangun} candi.")
        else:
            print("Bangun gagal. Kurang",end=" ")
            kurangbahan = [totbahan[0]-(arr_bahanbangunan[1])[2],totbahan[1]-(arr_bahanbangunan[2])[2],totbahan[2]-(arr_bahanbangunan[3])[2]]
            countbarang = 0
            for i in range(3):
                if kurangbahan[i] > 0: countbarang += 1
            i,count = 0,0
            while i<3 and count < countbarang:
                if kurangbahan[i] > 0:
                    count += 1
                    if count < countbarang:
                        if countbarang > 2: print(f"{kurangbahan[i]} {(arr_bahanbangunan[i+1])[0]}",end=", ")
                        else: print(f"{kurangbahan[i]} {(arr_bahanbangunan[i+1])[0]}",end=" ")
                    else:
                        if countbarang > 1: print("dan",end=" ")
                        print(f"{kurangbahan[i]} {(arr_bahanbangunan[i+1])[0]}.")
                i += 1
    else: print("Bangun gagal. Anda tidak punya jin pembangun. Silahakn summon terlebih dahulu.")