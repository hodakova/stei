data_jin = {}

def hapusjin():
    # Apabila belum ada jin yang di-summon
    if data_jin == {}:
        print("Belum ada jin yang di-summon")
    else :
        print("Username jin yang telah di-summon: ")
        dt.jin(data_jin)
        username = input("Masukkan username jin: ") # Input username jin yang ingin di hapus
    
    # Validasi penghapusan jin
    if username not in data_jin:
        print("Tidak ada jin dengan username tersebut.")
    else:
        validate = input("Apakah anda yakin ingin menghapus jin dengan username" + username + "(Y/N)?")
        if validate == "Y":
            del data_jin[username]
            print("Jin telah berhasil dihapus dari alam gaib.")
        elif validate == "N":
            print("Jin tidak berhasil dihapus dari alam gaib.")   
        else :
            print("Masukkan (Y/N) untuk mengkonfirmasi penghapusan") # Apabila input merupakan command yang tidak diketahui

    # Informasi mengenai sisa jin yang ada        
    print("Sisa jin yang tersedia: ")
    if data_jin == {}:
        print("Belum ada jin yang di-summon")
    else :
        print("Username jin yang telah di-summon: ")
        dt.jin(data_jin)