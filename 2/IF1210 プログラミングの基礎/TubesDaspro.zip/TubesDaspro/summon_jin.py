data_jin = {}

def summonjin():
    # Pilihan jenis - jenis jin
    print("Jenis jin yang dapat dipanggil:")
    print("(1) Pengumpul - Bertugas mengumpulkan bahan bangunan")
    print("(2) Pembangun - Bertugas membangun candi")
    
    # Input jin yang ingin di-summon
    jenis = input("Masukkan nomor jenis jin yang ingin dipanggil: ")
    while jenis not in ["1", "2"]:
        jenis = input("Tidak ada jenis jin bernomor" + jenis)
    if jenis == "1":
        jenis_jin = "Pengumpul"
    elif jenis == "2":
        jenis_jin = "Pembangun"
    
    # Mengecek apakah username yang di-input sudah ada atau belum
    username = input("Masukkan username jin: ")
    while username not in data_jin:
        username = input("Username '" + username + " sudah diambil. Masukkan username jin: ")
    
    # Mengecek apakah password yang di-input sesuai dengan syarat atau tidak
    password = input("Masukkan password jin (5-25 karakter): ") 
    while len(password) < 5 or len(password) > 25:
        password = input("Password panjangnya harus 5-25 karakter! Masukkan password jin: ")
    
    # Proses summon jin
    print("Mengumpulkan sesajen...")
    print("Menyerahkan sesajen...")
    print("Membacakan mantra...")
    print("Jin '" + username + "' berhasil dipanggil!")
    
    # Memasukkan username & password jin yang telah di-summon ke dalam database
    data_jin[username] = {"jenis": jenis_jin, "password": password} 
    
    # Menolak untuk summon jin apabila sudah mencapai limit 100
    if len(data_jin) >= 100:
        print("Jumlah Jin telah maksimal! (100 jin). Bandung tidak dapat men-summon lebih dari itu")