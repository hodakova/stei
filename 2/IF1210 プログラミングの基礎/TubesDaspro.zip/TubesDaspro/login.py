from load import arr_user

username = input("Username: ")
password = input("Password: ")

for i in range(1, 103) :
    if (username == (arr_user[i])[0] and password == (arr_user[i])[1]) : # Jika username & password benar
        print("")
        print(f"Selamat datang, {username}!")
        k = i
        break
    elif (i == 103-1) : # Jika telah mengecek seluruh list username namun tidak ditemukan username yang di input input
        print("")
        print("Password salah!")
        break
    elif (username == (arr_user[i])[0]) : # Jika username benar namun password salah
        print("")
        print("Password salah!")
        break

import help
teshelp = help.help((arr_user[k])[2])