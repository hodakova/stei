from load import arr_candi

total_candi = 0
total_pasir = 0
total_air = 0
total_batu = 0

for i in range (1,1000) :
    if((arr_candi[i])[0] != None) :
        total_candi = total_candi + 1

for i in range (1,1000) :
    if ((arr_candi[i])[2] != None) :
        total_pasir = total_pasir + arr_candi[i][2]

for i in range (1,1000) :
    if ((arr_candi[i])[3] != None) :
        total_batu = total_batu + arr_candi[i][3]

for i in range (1,1000) :
    if ((arr_candi[i])[4] != None) :
        total_air = total_air + arr_candi[i][4]

max = 0
min = 0
letak_id_max = (arr_candi[0])[0]
letak_id_min = (arr_candi[0])[0]

for i in range (1000) :
    if (max <= 10000*(arr_candi[i])[2] + 15000*(arr_candi[i])[3] + 7500*(arr_candi[i])[4]) :
        max = 10000*(arr_candi[i])[2] + 15000*(arr_candi[i])[3] + 7500*(arr_candi[i])[4]
        letak_id_max = (arr_candi[i])[0]

for i in range (1000) :
    if (min >= 10000*(arr_candi[i])[2] + 15000*(arr_candi[i])[3] + 7500*(arr_candi[i])[4]) :
        min = 10000*(arr_candi[i])[2] + 15000*(arr_candi[i])[3] + 7500*(arr_candi[i])[4]
        letak_id_min = (arr_candi[i])[0]

print("Total Candi : ",total_candi)
print("Total Pasir yang digunakan : ",total_pasir)
print("Total Batu yang digunakan : ",total_batu)
print("Total Air yang digunakan : ",total_air)
print("ID Candi Termahal : ",letak_id_max,"(",max,")")
print("ID Candi Termurah : ",letak_id_min,"(",min,")")