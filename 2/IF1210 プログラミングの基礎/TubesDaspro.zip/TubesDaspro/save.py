# STEP 1 : buat folder parent(cek dulu folder parent udh ada atau belom, kalau belom ada, bikin pake os.mkdir("save/"+folder)) 
# STEP 2 : buka file user/candi/bahan bangunan di folder yang baru dibuat (user = open("save/"+folder+"/user.csv", "w+"))
# pake 'w' aja cukupp,  buka file dan nulis file kalo udah ada, kalopun filenya belum ada, file bakal dibikin
# STEP 3 : pindahin isi array ke file pake user.write


import os.path

def findlength(data):
    count = 0
    for i in data :
        count =+ 1
    
    return count

def save() :
    folder = input("Masukkan nama folder : ")
    print("Saving...")
    if not os.path.isdir("save") :
        print("Membuat folder save")
        os.mkdir("save")
    if not os.path.isdir(folder):
        print("Membuat folder save/"+folder)
        os.mkdir("save/"+folder)

    user = open("save/"+folder+"/user.csv", 'w')

    for i in range (len(data_user)) :
        line = data_user[i][0]
        for j in range (1,3) :
            line += ";"+ data_user[i][j]
        user.write(line)
    user.close()

    candi = open("save/"+folder+"/candi.csv", 'w')

    for i in range (len(data_user)) :
        line = data_user[i][0]
        for j in range (1,3) :
            line += ";"+ data_user[i][j]
        candi.write(line)
    candi.close()

    bahan_bangunan = open("save/"+folder+"/bahan_bangunan.csv", 'w')

    for i in range (len(data_user)) :
        line = data_user[i][0]
        for j in range (1,3) :
            line += ";"+ data_user[i][j]
        bahan_bangunan.write(line)
    bahan_bangunan.close()

