def help(role) :

    if role == "bandung_bondowoso" :
        #Bandung Bondowoso
        print("="*11, "HELP", "="*11)
        print("1. logout \nUntuk keluar dari akun yang digunakan sekarang")
        print("2. summonjin \nUntuk memanggil jin")
        print("3. hapusjin \nUntuk menghapus jin")
        print("4. ubahjin \nUntuk mengubah tipe jin, dari jin tipe pembangun menjadi tipe pengumpul maupun sebaliknya")
        print("5. batchkumpul \nUntuk membuat seluruh jin tipe pengumpul mengumpulkan bahan")
        print("6. batchbangun \nUntuk membuat seluruh jin tipe pembangun membangun candi")
        print("7. laporanjin \nUntuk mengambil laporan kinerja jin yang berisi :\n- Jumalah jin total\n- Jumlah jin pengumpul\n- Jumlah jin pembangun\n- Jin Terajin\n- Jin Termalas\n- Jumlah pasir\n- Jumlah air\n- Jumlah batu")
        print("8. laporancandi\nUntuk mengambil laporan progress pembangunan candi yang berisi \n- Jumlah candi total\n- Jumlah total pasir yang digunakan\n- Jumlah totalbatu yang digunakan\n- Jumlah total air yang digunakan\n- ID candi termahal\n- ID candi termurah")
        print("9. save \nUntuk menjalankan prosedur menyimpan data")
        print("10. exit \nUntuk keluar dari program dan kembali ke terminal")
        pilihan = input(">>> ")
        if pilihan == '1' :
            import logout
            teslogout = logout()
        if pilihan == '2' :
            import summon_jin
            tessummon = summon_jin()
        if pilihan == '3' :
            import hapus_jin
            teshapusjin = hapus_jin()
        if pilihan == '4' :
            from Fungsi58 import ubahjin
            tesubahjin = ubahjin()
        if pilihan == '5' :
            from Fungsi58 import rawkumpul, batchkumpul
            tesraw = rawkumpul()
            tesbatchk = batchkumpul()
        if pilihan == '6' :
            from Fungsi58 import batchbangun
            tesbatchb = batchbangun()
        if pilihan == '7' :
            import LaporanJin
            teslaporanjin = LaporanJin()
        if pilihan == '8' :
            import laporanCandi
            teslaporancandi = laporanCandi()
        if pilihan == '9' :
            import save
            tessave = save()
        if pilihan == '10' :
            import exit
            tesexit = exit()

    elif role == "roro_jonggrang" :
        #Roro Jonggrang
        print("="*11, "HELP", "="*11)
        print("1. logout \nUntuk keluar dari akun yang digunakan sekarang")
        print("2. hancurkancandi\nuntuk menghancurkan candi")
        print("3. ayamberkokok\nUntuk menyelesaikan permainan dengan memalsukan pagi hari")
        print("4. save \nUntuk menjalankan prosedur menyimpan data")
        print("5. exit \nUntuk keluar dari program dan kembali ke terminal")
        pilihan2 = input(">>> ")
        if pilihan2 == '1' :
            import logout
            teslogout = logout()
        if pilihan2 == '2' :
            import HancurkanCandi
            teshancur = HancurkanCandi()
        if pilihan2 == '3' :
            import AyamBerkokok
            tesayam = AyamBerkokok()
        if pilihan2 == '4' :
            import save
            tessave = save()
        if pilihan2 == '5' :
            import exit
            tesexit= exit()

    elif role == "jin_pengumpul" :
        #Jin Pengumpul
        print("="*11, "HELP", "="*11)
        print("1. logout \nUntuk keluar dari akun yang digunakan sekarang")
        print("2. kumpul \nUntuk mengumpulkan resource candi")
        print("3. save \nUntuk menjalankan prosedur menyimpan data")
        print("4. exit \nUntuk keluar dari program dan kembali ke terminal")
        pilihan3 = input(">>> ")
        if pilihan3 == '1' :
            import logout
            teslogout = logout()
        if pilihan3 == '2' :
            from Fungsi58 import rawkumpul, kumpul
            tesraw = rawkumpul()
            teskumpul = kumpul()
        if pilihan3 == '3' :
            import save
            tessave = save()
        if pilihan3 == '4' :
            import exit
            tesexit = exit()

    elif role == "jin_pembangun" :
        #Jin Pembangun 
        print("="*11, "HELP", "="*11)
        print("1. logout \nUntuk keluar dari akun yang digunakan sekarang")
        print("2. bangun \nUntuk membangun candi")
        print("3. save \nUntuk menjalankan prosedur menyimpan data")
        print("4. exit \nUntuk keluar dari program dan kembali ke terminal")
        pilihan4 = input(">>> ")
        if pilihan4 == '1' :
            import logout
            teslogout = logout()
        if pilihan4 == '2' :
            from Fungsi58 import bangun
            tesbangun = bangun()
        if pilihan4 == '3' :
            import save
            tessave = save()
        if pilihan4 == '4' :
            import exit
            tesexit = exit()