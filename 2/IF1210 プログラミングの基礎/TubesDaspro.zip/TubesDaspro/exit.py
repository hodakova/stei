def exit() :    
    ask = input("Apakah Anda mau melakukan penyimpanan file yang sudah diubah? (y/n)")

    while ask!= "n" and ask!="N" and ask!="Y" and ask!="y" :
        ask = input("Apakah Anda mau melakukan penyimpanan file yang sudah diubah? (y/n)")

    if ask == "n" or ask == "N" :
        exit()
    elif ask == "y" or ask =="Y" :
        import save
        tessave = save()
        exit()