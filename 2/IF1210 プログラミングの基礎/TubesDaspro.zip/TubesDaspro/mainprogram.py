print("1. Login")
print("2. Exit")
masukan = input(">>> ")

if masukan == '1' :
    import login
    teslogin = login
elif masukan == '2' :
    import exit
    tesexit = exit