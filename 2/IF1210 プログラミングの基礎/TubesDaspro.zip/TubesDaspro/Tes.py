f = open("dataku.txt",'w')
cc = input()

while (cc != '.') :
    f.write(cc)
    cc = input()

f.write('.')
f.close()
