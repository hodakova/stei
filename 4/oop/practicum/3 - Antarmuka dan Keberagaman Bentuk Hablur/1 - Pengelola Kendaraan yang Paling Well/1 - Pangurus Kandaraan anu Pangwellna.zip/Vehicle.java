public interface Vehicle {
    public void park();
}
