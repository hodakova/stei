public interface Tyre {
    public void changeTyre();
}
